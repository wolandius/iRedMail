# Author: Zhang Huangbin <zhb@iredmail.org>

# fmt: off
urls = [
    '/system', 'controllers.panel.log.Log',
    '/activities/admins', 'controllers.panel.log.Log',
]
# fmt: on
