> Don't forget to check out our lightweight email archiving software: https://spiderd.io/

* Download packed stable release tarballs:
  https://dl.iredmail.org/yum/misc/

* Installation Guide, Release Notes, Upgrade Tutorials:
  https://docs.iredmail.org/iredadmin-pro.releases.html

* Please report bugs in our forum:
  https://forum.iredmail.org/
