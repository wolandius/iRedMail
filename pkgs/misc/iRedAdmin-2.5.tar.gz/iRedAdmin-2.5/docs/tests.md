# Perform unit tests

## docstring tests

```
python3 -m doctest path/to/file.py
```
