* Verify archive directory existence after removed account.
