# TODO

## API

- Rename a mailing list
- View or remove pending subscription subscribers
- Able to update parameter for ALL accounts under same domain.

## Archiving

- Write scripts to convert archived emails of public mailing list to web pages.
- Support multiple list addresses.
